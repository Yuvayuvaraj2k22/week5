# WordCount
# Word Count 
 
In this project have to print the first three most common words that appear in a given text.

## Steps to Run the Project

Step 1:  Press "ctrl + shift + i" to open the console.

Step 2:  It returns the most three common words.

## Future improvements

The project can be further enhanced by adding spell checkers and improves or alters some additional resource.  

